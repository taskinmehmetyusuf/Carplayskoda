package com.carplaydrive.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(24))
            setBackgroundColor(0xFF080D18.toInt())
        }
        fun text(value: String, size: Float, color: Int) =
            TextView(this).apply { text = value; textSize = size; setTextColor(color) }
        fun button(value: String, action: () -> Unit) =
            Button(this).apply { text = value; setOnClickListener { action() } }

        root.addView(text("CARPLAY DRIVE", 27f, 0xFFFFFFFF.toInt()))
        root.addView(text("Müzik • Navigasyon • IPTV • YouTube", 14f, 0xFFB8C7DA.toInt()))
        root.addView(button("Google Maps'i Aç") {
            val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q="))
                .setPackage("com.google.android.apps.maps")
            if (nav.resolveActivity(packageManager) != null) startActivity(nav)
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com")))
        })
        root.addView(button("YouTube'u Aç") {
            val app = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            if (app != null) startActivity(app)
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
        })
        root.addView(text("IPTV", 21f, 0xFFFFFFFF.toInt()))
        root.addView(text("Yalnızca izleme hakkına sahip olduğun yayın listelerini kullan.", 13f, 0xFFB8C7DA.toInt()))

        val playlist = EditText(this).apply {
            hint = "M3U / M3U8 oynatma listesi URL'si"
            singleLine = true
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF8091A8.toInt())
        }
        root.addView(playlist, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(54)
        ))
        root.addView(button("M3U listesini yükle") {
            val url = playlist.text.toString().trim()
            if (url.isNotEmpty()) startActivity(
                Intent(this, IptvPlayerActivity::class.java).putExtra("mode", "m3u").putExtra("url", url)
            ) else playlist.error = "M3U bağlantısını gir"
        })

        val server = EditText(this).apply {
            hint = "Xtream sunucu adresi (örn. https://sunucu:port)"
            singleLine = true
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF8091A8.toInt())
        }
        val username = EditText(this).apply {
            hint = "Xtream kullanıcı adı"; singleLine = true
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF8091A8.toInt())
        }
        val password = EditText(this).apply {
            hint = "Xtream şifre"; singleLine = true
            inputType = 0x81
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF8091A8.toInt())
        }
        root.addView(server)
        root.addView(username)
        root.addView(password)
        root.addView(button("Xtream kanallarını getir") {
            if (server.text.isNullOrBlank() || username.text.isNullOrBlank() || password.text.isNullOrBlank()) {
                server.error = "Sunucu, kullanıcı adı ve şifre gerekli"
            } else {
                startActivity(Intent(this, IptvPlayerActivity::class.java)
                    .putExtra("mode", "xtream")
                    .putExtra("server", server.text.toString().trim())
                    .putExtra("username", username.text.toString().trim())
                    .putExtra("password", password.text.toString()))
            }
        })
        root.addView(text(
            "Not: Video oynatma telefon ekranında/park halinde kullanım içindir; Android Auto sürüş ekranında video gösterilmez.",
            12f, 0xFFFFCC80.toInt()
        ))
        setContentView(root)
    }
}
