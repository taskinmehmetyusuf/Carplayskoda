# CarPlay Drive 1.1

Android Studio starter project with:
- Google Maps handoff
- YouTube app/web handoff
- M3U/M3U8 playlist URL loading
- Xtream Codes live-channel list loading
- HLS/stream playback through AndroidX Media3 ExoPlayer
- GitHub Actions debug APK workflow

## Safety and platform limits
Video playback is provided only in the phone-side app. Do not use YouTube or IPTV
video while driving. Android Auto does not allow arbitrary video apps on its
driving display; this project does not show video on Android Auto.

The Android Auto media browser service is still a starter shell. It does not
publish the IPTV catalogue as an Android Auto media catalogue. This requires a
separate audio-focused media implementation and policy-compliant testing.

## Build
Open in Android Studio with JDK 17, sync Gradle, then Build > Build APK(s).
Or push to GitHub and run Actions > Build CarPlay Drive APK.

## IPTV
Enter a lawful M3U/M3U8 URL or Xtream server, username and password. Credentials
are used to request the channel list; keep them private and use only a provider
you are authorized to access. This starter does not include any channel list or
paid IPTV credentials. Some providers require extra headers, TLS settings, or
different stream URL formats and may need adaptation.
