package com.carplaydrive.app

import android.os.AsyncTask
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class Channel(val name: String, val streamUrl: String)

class IptvPlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var playerView: PlayerView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(12))
            setBackgroundColor(0xFF080D18.toInt())
        }
        status = TextView(this).apply {
            text = "Kanallar yükleniyor…"; textSize = 16f; setTextColor(0xFFFFFFFF.toInt())
        }
        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220)
            )
            useController = true
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(status)
        root.addView(playerView)
        root.addView(list)
        setContentView(root)

        when (intent.getStringExtra("mode")) {
            "m3u" -> loadM3u(intent.getStringExtra("url") ?: "")
            "xtream" -> loadXtream(
                intent.getStringExtra("server") ?: "",
                intent.getStringExtra("username") ?: "",
                intent.getStringExtra("password") ?: ""
            )
            else -> status.text = "Geçersiz IPTV bağlantısı"
        }
    }

    private fun fetch(url: String, callback: (String?, String?) -> Unit) {
        object : AsyncTask<Void, Void, Pair<String?, String?>>() {
            override fun doInBackground(vararg params: Void?): Pair<String?, String?> {
                return try {
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.connectTimeout = 15000
                    connection.readTimeout = 20000
                    connection.setRequestProperty("User-Agent", "CarPlayDrive/1.1")
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    connection.disconnect()
                    Pair(body, null)
                } catch (e: Exception) {
                    Pair(null, e.message ?: "Bağlantı hatası")
                }
            }
            override fun onPostExecute(result: Pair<String?, String?>) {
                callback(result.first, result.second)
            }
        }.execute()
    }

    private fun loadM3u(url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            status.text = "Geçerli bir http/https M3U URL'si gir."
            return
        }
        fetch(url) { body, error ->
            if (body == null) {
                status.text = "M3U yüklenemedi: $error"
                return@fetch
            }
            val channels = mutableListOf<Channel>()
            var name = "Kanal"
            body.lineSequence().forEach { raw ->
                val line = raw.trim()
                when {
                    line.startsWith("#EXTINF", true) ->
                        name = line.substringAfterLast(",").trim().ifBlank { "Kanal" }
                    line.isNotEmpty() && !line.startsWith("#") &&
                        (line.startsWith("http://") || line.startsWith("https://")) -> {
                        channels.add(Channel(name, line))
                        name = "Kanal"
                    }
                }
            }
            showChannels(channels)
        }
    }

    private fun loadXtream(serverInput: String, user: String, pass: String) {
        val server = serverInput.trimEnd('/')
        val api = "$server/player_api.php?username=${java.net.URLEncoder.encode(user, "UTF-8")}" +
            "&password=${java.net.URLEncoder.encode(pass, "UTF-8")}&action=get_live_streams"
        fetch(api) { body, error ->
            if (body == null) {
                status.text = "Xtream bağlantısı başarısız: $error"
                return@fetch
            }
            try {
                val json = JSONArray(body)
                val channels = mutableListOf<Channel>()
                for (i in 0 until json.length()) {
                    val item = json.getJSONObject(i)
                    val title = item.optString("name", "Kanal")
                    val id = item.optString("stream_id")
                    if (id.isNotBlank()) {
                        channels.add(Channel(title, "$server/live/$user/$pass/$id.ts"))
                    }
                }
                showChannels(channels)
            } catch (e: Exception) {
                status.text = "Xtream yanıtı okunamadı: ${e.message}"
            }
        }
    }

    private fun showChannels(channels: List<Channel>) {
        list.removeAllViews()
        status.text = if (channels.isEmpty()) "Kanal bulunamadı." else "${channels.size} kanal bulundu"
        channels.forEach { channel ->
            list.addView(Button(this).apply {
                text = channel.name
                setOnClickListener { play(channel.streamUrl) }
            })
        }
    }

    private fun play(url: String) {
        try {
            if (player == null) {
                player = ExoPlayer.Builder(this).build().also { playerView.player = it }
            }
            player?.setMediaItem(MediaItem.fromUri(url))
            player?.prepare()
            player?.play()
        } catch (e: Exception) {
            Toast.makeText(this, "Yayın açılamadı: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onStop() {
        player?.release()
        player = null
        playerView.player = null
        super.onStop()
    }
}
