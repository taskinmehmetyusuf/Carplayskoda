package com.carplaydrive.app

import android.os.Bundle
import android.service.media.MediaBrowserService
import android.media.browse.MediaBrowser
import android.media.session.MediaSession
import android.media.session.PlaybackState

class CarMediaBrowserService : MediaBrowserService() {
    private lateinit var session: MediaSession

    override fun onCreate() {
        super.onCreate()
        session = MediaSession(this, "CarPlayDriveSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {}
                override fun onPause() {
                    setPlaybackState(
                        PlaybackState.Builder()
                            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE)
                            .setState(PlaybackState.STATE_PAUSED, 0L, 1f)
                            .build()
                    )
                }
            })
            setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            setPlaybackState(
                PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE)
                    .setState(PlaybackState.STATE_PAUSED, 0L, 1f)
                    .build()
            )
            isActive = true
        }
        setSessionToken(session.sessionToken)
    }

    override fun onGetRoot(clientPackageName: String, clientUid: Int, rootHints: Bundle?) =
        BrowserRoot("root", null)

    override fun onLoadChildren(parentId: String, result: Result<List<MediaBrowser.MediaItem>>) {
        result.sendResult(emptyList())
    }

    override fun onDestroy() {
        if (::session.isInitialized) session.release()
        super.onDestroy()
    }
}
